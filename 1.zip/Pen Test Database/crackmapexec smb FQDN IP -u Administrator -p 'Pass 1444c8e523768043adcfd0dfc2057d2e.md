# crackmapexec smb <FQDN/IP> -u Administrator -p 'Password123!' -x 'whoami' --exec-method smbexec

OS: Linux
Description: Crackmapexec Execute Command
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21), Execution (https://www.notion.so/Execution-1444c8e52376808b8c78d6d58e52f8a7?pvs=21)
Target_Technology: smb (https://www.notion.so/smb-1434c8e5237680e7b5c3ffe1f7ead9e1?pvs=21)