# nfs mount shared folder

OS: Linux
Description: nfs mount folder
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: Bash (https://www.notion.so/Bash-1434c8e5237680b5aa14d2174d201e9a?pvs=21)

```jsx
sudo mount -t nfs 10.129.2.12:/tmp /mnt
```