# openssl s_client -connect <FQDN/IP>:21 -starttls ftp

OS: Linux
Description: Interact with FTP over SSL/TLS
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: ftp (https://www.notion.so/ftp-1434c8e5237680bcaf18c24e9f10cb87?pvs=21)