# sqlplus <user>/<pass>@<FQDN/IP>/<db>

OS: Linux
Description: oracle database login
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: oracle (https://www.notion.so/oracle-1444c8e5237680789600f1b15e3fa0ec?pvs=21)