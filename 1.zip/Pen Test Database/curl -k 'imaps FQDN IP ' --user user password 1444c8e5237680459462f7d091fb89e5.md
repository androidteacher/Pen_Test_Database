# curl -k 'imaps://<FQDN/IP>' --user <user>:<password>

OS: Linux
Description: Log in to the IMAPS service using cURL.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: imaps (https://www.notion.so/imaps-1444c8e5237680e39c45ef6c42dcf61c?pvs=21)