# python3 o365spray.py --validate --domain msplaintext.xyz

OS: Linux
Description: Verify the usage of Office365 for the specified domain.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: smtp (https://www.notion.so/smtp-1444c8e523768063a9fad4623d09ce5d?pvs=21)
URL: https://github.com/0xZDH/o365spray