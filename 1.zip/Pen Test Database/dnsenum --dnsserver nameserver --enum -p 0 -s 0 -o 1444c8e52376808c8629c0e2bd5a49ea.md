# dnsenum --dnsserver <nameserver> --enum -p 0 -s 0 -o found_subdomains.txt -f ~/subdomains.list <domain.tld>

OS: Linux
Description: Subdomain brute forcing.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: dns (https://www.notion.so/dns-1444c8e52376808aa820e13096bf807f?pvs=21)
URL: https://github.com/fwaeytens/dnsenum