# python3 -m http.server 8123

OS: Linux
Description: Simple Python3 webserver on port 8123
Security Domains: File Transfer (https://www.notion.so/File-Transfer-1444c8e52376809ba2ecfc98dc62c772?pvs=21)
Target_Technology: python (https://www.notion.so/python-1444c8e523768064b118fb3c0d424051?pvs=21)