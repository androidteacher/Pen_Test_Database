# windows ‘net’ command reference

OS: Windows
Description: windows ‘net’ command reference
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: PowerShell (https://www.notion.so/PowerShell-1434c8e52376805dba60efbabdb026bf?pvs=21)

### **Table of Useful Net Commands**

| **Command** | **Description** |
| --- | --- |
| `net accounts` | Information about password requirements |
| `net accounts /domain` | Password and lockout policy |
| `net group /domain` | Information about domain groups |
| `net group "Domain Admins" /domain` | List users with domain admin privileges |
| `net group "domain computers" /domain` | List of PCs connected to the domain |
| `net group "Domain Controllers" /domain` | List PC accounts of domains controllers |
| `net group <domain_group_name> /domain` | User that belongs to the group |
| `net groups /domain` | List of domain groups |
| `net localgroup` | All available groups |
| `net localgroup administrators /domain` | List users that belong to the administrators group inside the domain (the group `Domain Admins` is included here by default) |
| `net localgroup Administrators` | Information about a group (admins) |
| `net localgroup administrators [username] /add` | Add user to administrators |
| `net share` | Check current shares |
| `net user <ACCOUNT_NAME> /domain` | Get information about a user within the domain |
| `net user /domain` | List all users of the domain |
| `net user %username%` | Information about the current user |
| `net use x: \computer\share` | Mount the share locally |
| `net view` | Get a list of computers |
| `net view /all /domain[:domainname]` | Shares on the domains |
| `net view \computer /ALL` | List shares of a computer |
| `net view /domain` | List of PCs of the domain |