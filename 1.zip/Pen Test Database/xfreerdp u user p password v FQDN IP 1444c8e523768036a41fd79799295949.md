# xfreerdp /u:<user> /p:"<password>" /v:<FQDN/IP>

OS: Linux
Description: rdp client
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21), Initial Access (https://www.notion.so/Initial-Access-1444c8e5237680db9b3afd69d2c38487?pvs=21)
Target_Technology: rdp (https://www.notion.so/rdp-1444c8e52376801fbd7defc74098df00?pvs=21)