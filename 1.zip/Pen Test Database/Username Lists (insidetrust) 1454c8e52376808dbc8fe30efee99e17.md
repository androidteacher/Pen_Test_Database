# Username Lists (insidetrust)

OS: Web
Description: Username wordlists
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21), Resource Development (https://www.notion.so/Resource-Development-1444c8e523768023b086cae715467df4?pvs=21)
Target_Technology: wordlist (https://www.notion.so/wordlist-1454c8e5237680dc9485ca66c9aa943d?pvs=21)

```jsx
https://github.com/insidetrust/statistically-likely-usernames
```