# ssh -L 1234:localhost:3306 Ubuntu@<IPaddressofTarget>

OS: Linux
Description: SSH comand used to create an SSH tunnel from a local machine on local port 1234 to a remote target using port 3306.
Security Domains: Lateral Movement (https://www.notion.so/Lateral-Movement-1444c8e5237680dea1fed00199ad754d?pvs=21)
Target_Technology: Bash (https://www.notion.so/Bash-1434c8e5237680b5aa14d2174d201e9a?pvs=21), ssh (https://www.notion.so/ssh-1444c8e5237680f29279ce80e0cf529b?pvs=21)