# Kerberos force RC4 Encryption

OS: Active_Directory
Description: Kerberos force RC4 Encryption
Security Domains: Credential Access (https://www.notion.so/Credential-Access-1444c8e523768003b6fde866419041dc?pvs=21)
Target_Technology: PowerShell (https://www.notion.so/PowerShell-1434c8e52376805dba60efbabdb026bf?pvs=21)

- We can force rc4 encryption with the /tgtdeleg flag

![Untitled](Kerberos%20force%20RC4%20Encryption/Untitled.png)

### Kerberos Encryption is configured here:

![Untitled](Kerberos%20force%20RC4%20Encryption/Untitled%201.png)