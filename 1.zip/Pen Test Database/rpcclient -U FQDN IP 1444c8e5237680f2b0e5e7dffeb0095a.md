# rpcclient -U "" <FQDN/IP>

OS: Linux
Description: Interaction with the target using RPC.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: smb (https://www.notion.so/smb-1434c8e5237680e7b5c3ffe1f7ead9e1?pvs=21), rpc (https://www.notion.so/rpc-1444c8e5237680da82dbc974cd78a3f5?pvs=21)