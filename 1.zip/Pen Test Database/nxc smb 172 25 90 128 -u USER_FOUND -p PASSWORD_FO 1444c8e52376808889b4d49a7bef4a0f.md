# nxc smb 172.25.90.128 -u USER_FOUND -p PASSWORD_FOUND -M spider_plus

OS: Linux
Description: Enumerate smb share and create .json file
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: smb (https://www.notion.so/smb-1434c8e5237680e7b5c3ffe1f7ead9e1?pvs=21)
URL: https://github.com/Pennyw0rth/NetExec