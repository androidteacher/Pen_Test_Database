# mysql -u <user> -p<password> -h <FQDN/IP>

OS: Linux
Description: Login to the MySQL server.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: mysql (https://www.notion.so/mysql-1444c8e523768019a5acd8abdc5f59f6?pvs=21)