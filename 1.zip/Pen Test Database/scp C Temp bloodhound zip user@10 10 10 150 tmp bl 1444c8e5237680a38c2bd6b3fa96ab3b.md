# scp C:\Temp\bloodhound.zip user@10.10.10.150:/tmp/bloodhound.zip

OS: Linux
Description: Copy file from one computer to another: scp
Security Domains: File Transfer (https://www.notion.so/File-Transfer-1444c8e52376809ba2ecfc98dc62c772?pvs=21)
Target_Technology: ssh (https://www.notion.so/ssh-1444c8e5237680f29279ce80e0cf529b?pvs=21)