# cewl: generate wordlists from webpage

OS: Linux
Description: generate wordlist from webpage
Security Domains: Resource Development (https://www.notion.so/Resource-Development-1444c8e523768023b086cae715467df4?pvs=21)
Target_Technology: Bash (https://www.notion.so/Bash-1434c8e5237680b5aa14d2174d201e9a?pvs=21)

```jsx
cewl https://www.targetdomain.com -d 4 -m 6 --lowercase -w inlane.wordlist
```