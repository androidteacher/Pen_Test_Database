# Linux: Firefox .json containing encrypted passwords and decrypt

OS: Linux
Description: Linux: Firefox .json containing encrypted passwords
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21), Credential Access (https://www.notion.so/Credential-Access-1444c8e523768003b6fde866419041dc?pvs=21)
Target_Technology: Bash (https://www.notion.so/Bash-1434c8e5237680b5aa14d2174d201e9a?pvs=21)

```jsx
cat .mozilla/firefox/1bplpd86.default-release/logins.json | jq .
```

Decrypt

```jsx
https://github.com/unode/firefox_decrypt
```