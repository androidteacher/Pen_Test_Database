# Windows sqlite Browser

OS: Windows
Description: sqlite browser
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: windows (https://www.notion.so/windows-1454c8e52376809bb701cef01e9f111a?pvs=21)

```jsx
https://sqlitebrowser.org/dl/
```