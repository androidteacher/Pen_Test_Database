# openssl s_client -connect <FQDN/IP>:pop3s

OS: Linux
Description: Connect to the POP3s service.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: pop3s (https://www.notion.so/pop3s-1444c8e52376809daed9f51270c28a69?pvs=21)