# ssh <user>@<FQDN/IP> -o PreferredAuthentications=password

OS: Linux
Description: enforce password authentication
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: ssh (https://www.notion.so/ssh-1444c8e5237680f29279ce80e0cf529b?pvs=21)