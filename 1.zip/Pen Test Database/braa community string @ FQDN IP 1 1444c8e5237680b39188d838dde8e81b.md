# braa <community string>@<FQDN/IP>:.1.*

OS: Linux
Description: Bruteforcing SNMP service OIDs.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: snmp (https://www.notion.so/snmp-1444c8e523768043b6accd2ebda01382?pvs=21)
URL: https://github.com/mteg/braa