# smbmap -H <FQDN/IP> --upload test.txt "notes\test.txt"

OS: Linux
Description: Upload File
Security Domains: Persistence (https://www.notion.so/Persistence-1434c8e523768074b5d4daa95c78dbbb?pvs=21)
Target_Technology: smb (https://www.notion.so/smb-1434c8e5237680e7b5c3ffe1f7ead9e1?pvs=21)