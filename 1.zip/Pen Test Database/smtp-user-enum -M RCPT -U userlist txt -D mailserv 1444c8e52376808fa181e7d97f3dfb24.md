# smtp-user-enum -M RCPT -U userlist.txt -D mailserver.local -t 127.0.0.1

OS: Linux
Description: enumerate smtp users
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: smtp (https://www.notion.so/smtp-1444c8e523768063a9fad4623d09ce5d?pvs=21)
URL: https://pentestmonkey.net/tools/user-enumeration/smtp-user-enum