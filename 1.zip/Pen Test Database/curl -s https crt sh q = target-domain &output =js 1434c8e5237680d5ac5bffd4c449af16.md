# curl -s https://crt.sh/\?q\=<target-domain>\&output\=json | jq .

OS: Linux, Windows
Description: Certificate transparency.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: HTTPs (https://www.notion.so/HTTPs-1434c8e523768019a037eea3c9eef66c?pvs=21)