# nmap -Pn -v -n -p80 -b anonymous:password@10.10.110.213 172.17.0.2

OS: Linux
Description: FTP Bounce Attack
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: ftp (https://www.notion.so/ftp-1434c8e5237680bcaf18c24e9f10cb87?pvs=21)