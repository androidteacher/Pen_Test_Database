# auxiliary/scanner/http/tomcat_mgr_login

OS: Linux, Web
Description: Tomcat Brute Force
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: metasploit (https://www.notion.so/metasploit-1444c8e5237680e18a59ff8a4a9f4f7c?pvs=21), tomcat (https://www.notion.so/tomcat-1444c8e523768076b6d7c8c5e2f1f55c?pvs=21)