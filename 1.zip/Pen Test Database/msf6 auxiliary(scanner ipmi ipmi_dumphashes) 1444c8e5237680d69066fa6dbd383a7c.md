# msf6 auxiliary(scanner/ipmi/ipmi_dumphashes)

OS: Linux
Description: Dump IPMI hashes.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: ipmi (https://www.notion.so/ipmi-1444c8e523768072b017fa81b4505c3b?pvs=21)