# evil-winrm -i <FQDN/IP> -u <user> -p <password>

OS: Linux
Description: winrm client
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: winrm (https://www.notion.so/winrm-1444c8e52376805991b6e10d41025783?pvs=21)