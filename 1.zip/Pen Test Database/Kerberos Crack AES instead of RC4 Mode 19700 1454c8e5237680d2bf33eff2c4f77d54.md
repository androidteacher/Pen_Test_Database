# Kerberos Crack AES instead of RC4: Mode 19700

OS: Active_Directory
Description: Kerberos Crack AES instead of RC4: Mode 19700
Security Domains: Credential Access (https://www.notion.so/Credential-Access-1444c8e523768003b6fde866419041dc?pvs=21)
Target_Technology: PowerShell (https://www.notion.so/PowerShell-1434c8e52376805dba60efbabdb026bf?pvs=21)

```jsx
**hashcat -m 19700 aes_to_crack /usr/share/wordlists/rockyou.txt** 
```