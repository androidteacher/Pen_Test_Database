# secretsdump SAM

OS: Linux, Windows
Description: secretsdump SAM Database
Security Domains: Credential Access (https://www.notion.so/Credential-Access-1444c8e523768003b6fde866419041dc?pvs=21)
Target_Technology: Bash (https://www.notion.so/Bash-1434c8e5237680b5aa14d2174d201e9a?pvs=21), impacket (https://www.notion.so/impacket-1444c8e523768059ab69ddf37318b307?pvs=21)

```jsx
[secretsdump.py](http://secretsdump.py/) -sam sam.save -security security.save -system system.save LOCAL
```