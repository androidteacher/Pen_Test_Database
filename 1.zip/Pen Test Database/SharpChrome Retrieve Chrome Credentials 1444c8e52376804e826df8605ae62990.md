# SharpChrome: Retrieve Chrome Credentials

OS: Windows
Description: Retrieve Chrome Credentials
Security Domains: Credential Access (https://www.notion.so/Credential-Access-1444c8e523768003b6fde866419041dc?pvs=21)
Target_Technology: PowerShell (https://www.notion.so/PowerShell-1434c8e52376805dba60efbabdb026bf?pvs=21), chrome (https://www.notion.so/chrome-1444c8e523768047a9f6d659e705cadf?pvs=21)
URL: https://github.com/GhostPack/SharpDPAPI/tree/master

```jsx
.\SharpChrome.exe logins /unprotect
```