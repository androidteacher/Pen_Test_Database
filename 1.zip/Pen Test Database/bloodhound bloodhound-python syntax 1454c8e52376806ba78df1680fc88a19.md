# bloodhound: bloodhound-python syntax

OS: Linux, Windows
Description: bloodhound bloodhound-python syntax
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: Bash (https://www.notion.so/Bash-1434c8e5237680b5aa14d2174d201e9a?pvs=21), bloodhound (https://www.notion.so/bloodhound-1474c8e52376807c8400efeed991bc37?pvs=21)

```jsx
bloodhound-python -u 'forend' -p 'Klmcargo2' -ns 172.16.5.5 -d inlanefreight.local -c all 
```