# showmount -e <FQDN/IP>

OS: Linux
Description: Show available NFS shares.
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: nfs (https://www.notion.so/nfs-1444c8e5237680b4ab46cb70103b1336?pvs=21)