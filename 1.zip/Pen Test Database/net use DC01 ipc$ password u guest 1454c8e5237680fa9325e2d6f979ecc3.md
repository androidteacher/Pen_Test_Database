# net use \\DC01\ipc$ "password" /u:guest

OS: Windows
Description: SMB username/password check
Security Domains: Initial Access (https://www.notion.so/Initial-Access-1444c8e5237680db9b3afd69d2c38487?pvs=21)
Target_Technology: windows (https://www.notion.so/windows-1454c8e52376809bb701cef01e9f111a?pvs=21), smb (https://www.notion.so/smb-1434c8e5237680e7b5c3ffe1f7ead9e1?pvs=21)