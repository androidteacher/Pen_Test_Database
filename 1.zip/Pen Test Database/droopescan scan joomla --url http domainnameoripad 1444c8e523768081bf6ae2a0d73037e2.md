# droopescan scan joomla --url http://<domainnameoripaddress>

OS: Linux, Web
Description: drupal enumeration
Security Domains: Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: drupal (https://www.notion.so/drupal-1444c8e523768011b91feea2c5207972?pvs=21)
URL: https://github.com/SamJoan/droopescan