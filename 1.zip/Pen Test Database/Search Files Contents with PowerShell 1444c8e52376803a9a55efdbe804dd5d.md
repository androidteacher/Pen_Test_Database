# Search Files Contents with PowerShell

OS: Windows
Description: Search File Contents with PowerShell
Security Domains: Credential Access (https://www.notion.so/Credential-Access-1444c8e523768003b6fde866419041dc?pvs=21), Reconnaissance (https://www.notion.so/Reconnaissance-1434c8e5237680fe960be92e51e13491?pvs=21)
Target_Technology: PowerShell (https://www.notion.so/PowerShell-1434c8e52376805dba60efbabdb026bf?pvs=21)

```jsx
select-string -Path C:\Users\htb-student\Documents\*.txt -Pattern password
```